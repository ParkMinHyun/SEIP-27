package com.samsung.android.camera.core2.ml

import android.os.SystemClock
import com.samsung.android.camera.core2.container.CodecConfiguration
import com.samsung.android.camera.core2.node.DynamicFunctionNode
import com.samsung.android.camera.core2.node.Node
import com.samsung.android.camera.core2.node.dualBokeh.samsung.SecDualBokehNodeBase
import com.samsung.android.camera.core2.node.filter.SecFilterNode
import com.samsung.android.camera.core2.node.imageCodec.samsung.SecImageCodecNodeBase
import com.samsung.android.camera.core2.node.watermark.WatermarkNode
import com.samsung.android.camera.core2.processor.nodeController.DraftNodeChainAccessor
import com.samsung.android.camera.core2.util.CLog
import java.util.concurrent.CompletableFuture

private const val TAG = "DraftSequenceExecutionProfiler"

/**
 * Drives one draft sequence's node lifecycle: resolves each executing node to a [WorkloadKey], asks the Predictor to
 * admit it, and feeds the observed outcome back at capture end. State is grouped by destination - [modelUpdate] buffers
 * what the Predictor learns from, [metricsRecorder] is the sole writer of the [CaptureMetrics] store, and
 * [draftNodeChainLifecycle] owns deinit timing.
 */
class DraftSequenceExecutionProfiler @JvmOverloads constructor(
    private val isPendingRequest: Boolean,
    private val captureMetrics: CaptureMetrics,
    private val deviceStateReader: DeviceStateReader,
    private val captureAvailablePacer: CaptureAvailablePacer,
    private val predictor: DraftSequenceExecutionPredictor,
    private val admissionPolicy: DraftSequenceAdmissionPolicy,
    draftSequenceMetrics: DraftSequenceMetrics = DraftSequenceMetrics(),
) {

    private val modelUpdate = ModelUpdateBuffer()
    private val metricsRecorder = MetricsRecorder(captureMetrics, draftSequenceMetrics, isPendingRequest)
    private val draftNodeChainLifecycle = DraftNodeChainLifecycle()
    private val sizeBucket = SizeBucket.of(captureMetrics.resultImageSize)

    private var draftSequenceNodeList: List<Node> = emptyList()
    private var draftSequenceExecutionSession: DraftSequenceExecutionSession? = null
    private var deviceStateSnapshot: DeviceStateSnapshot? = null
    private var draftSequenceStartTimeMs = 0L

    /**
     * Initializes draft-node-chain profiling and, before any node executes, starts this draft sequence on the pacer -
     * consuming the admission that gated this capture and refreshing what the next callback prices against.
     *
     * The key passed is the full configured chain, even before Bokeh's second input arrives; the pacer re-projects it
     * onto the burst's demoted shape. Encoding-only captures pace the RESERVED Encoding sequence, and JPEG passthrough
     * passes null so its admission is still consumed and the FIFO stays balanced.
     */
    fun initialize(accessor: DraftNodeChainAccessor) {
        draftNodeChainLifecycle.attach(accessor)
        draftSequenceNodeList = accessor.configuredNodeList
        draftSequenceStartTimeMs = SystemClock.uptimeMillis()

        val configuredWorkloadKeys = draftSequenceNodeList.mapNotNull { node ->
            resolveWorkloadKey(node, requireReadyToRun = false)
        }
        val gatingPacingDecision = captureAvailablePacer.startDraftSequence(
            configuredWorkloadKeys.takeIf { it.isNotEmpty() }?.let(::WorkloadSequenceKey),
            readBudgetMs(),
        )
        metricsRecorder.onDraftStart(
            gatingPacingDecision = gatingPacingDecision,
            pacerSessionId = captureAvailablePacer.getCurrentSessionId(),
        )

        // Observability inputs only - just the timeout budget must stay fresh per node. Sampling them once keeps
        // DeviceStateReader's blocking dispatcher work off every node transition.
        deviceStateSnapshot = deviceStateReader.read()
    }

    /**
     * Profiles one predictable node execution. OPTIONAL workloads are admitted by their remaining suffix upper bound,
     * hardened by the sticky group demotion in [DraftSequenceAdmissionPolicy] so one burst never alternates effects
     * between shots. REQUIRED work (DynamicFunction, Frame Watermark) always runs but is not reserve-protected; the
     * RESERVED workload is the mandatory tail.
     */
    fun profileNodeExecution(node: Node): DraftSequenceExecutionSession? {
        val workloadKey = resolveWorkloadKey(node, requireReadyToRun = true) ?: return null
        val workloadSequenceKey = WorkloadSequenceKey(resolveWorkloadSequenceKey(node, workloadKey))
        val preExecutionMetrics = readPreExecutionMetrics()
        val nodeExecutionMetrics = metricsRecorder.onNodeExecutionStart(
            nodeName = node.javaClass.simpleName,
            workloadKey = workloadKey,
            preExecutionMetrics = preExecutionMetrics,
        )

        val modelDecision = predictor.decideAdmission(workloadSequenceKey, preExecutionMetrics)
        val decision = modelDecision.copy(
            executionPrediction = modelDecision.executionPrediction.copy(
                admit = admissionPolicy.admit(
                    workloadKey = workloadKey,
                    hasFrameWatermark = workloadSequenceKey.hasFrameWatermark(),
                    modelAdmit = modelDecision.executionPrediction.admit,
                ),
            ),
        )
        modelUpdate.remember(decision)
        val prediction = decision.executionPrediction
        metricsRecorder.onPrediction(prediction)

        return createExecutionSession(
            workloadKey = workloadKey,
            workloadSequenceKey = workloadSequenceKey,
            preExecutionMetrics = preExecutionMetrics,
            nodeExecutionMetrics = nodeExecutionMetrics,
            prediction = prediction,
        )
    }

    private fun readPreExecutionMetrics(): PreExecutionMetrics {
        val deviceState = deviceStateSnapshot ?: deviceStateReader.read().also { snapshot ->
            deviceStateSnapshot = snapshot
        }
        return PreExecutionMetrics(
            budgetMs = readBudgetMs(),
            memorySnapshot = deviceState.memorySnapshot,
            thermalSnapshot = deviceState.thermalSnapshot,
            storageSnapshot = deviceState.storageSnapshot,
        )
    }

    private fun readBudgetMs(): Long {
        val nowMs = SystemClock.uptimeMillis()
        return captureMetrics.timeoutTimestampMsOrDefault - nowMs
    }

    private fun createExecutionSession(
        workloadKey: WorkloadKey,
        workloadSequenceKey: WorkloadSequenceKey,
        preExecutionMetrics: PreExecutionMetrics,
        nodeExecutionMetrics: NodeExecutionMetrics,
        prediction: ExecutionPrediction,
    ): DraftSequenceExecutionSession {
        val onComplete: (PostExecutionMetrics) -> Unit = { postExecutionMetrics ->
            metricsRecorder.onWorkloadCompleted(nodeExecutionMetrics, postExecutionMetrics)
            modelUpdate.recordWorkloadDuration(workloadKey, postExecutionMetrics.durationMs)
        }

        return when (workloadKey.policy) {
            WorkloadPolicy.OPTIONAL -> {
                val watchdogDecision = predictor.predictWatchdogTimeout(workloadSequenceKey, preExecutionMetrics)
                watchdogDecision.decision?.let(modelUpdate::remember)
                metricsRecorder.onWatchdogArmed(nodeExecutionMetrics, watchdogDecision.timeoutMs)
                DraftSequenceExecutionSession.createForOptionalWorkload(
                    shouldRun = prediction.admit,
                    watchdogTimeoutMs = watchdogDecision.timeoutMs,
                    onTimedOutTask = { worker ->
                        draftNodeChainLifecycle.deferUntil(worker)
                        metricsRecorder.onWatchdogTimedOut(nodeExecutionMetrics)
                    },
                    onComplete = onComplete,
                )
            }
            WorkloadPolicy.REQUIRED -> DraftSequenceExecutionSession.createForRequiredWorkload(onComplete)
            WorkloadPolicy.RESERVED -> DraftSequenceExecutionSession.createForReservedWorkload(
                onCancel = { draftSequenceExecutionSession = null },
                onComplete = onComplete,
            ).also { session ->
                draftSequenceExecutionSession = session
            }
        }
    }

    /** Completes RESERVED work, updates the learned duration/pacing models, and records whether it timed out. */
    fun completeDraftSequenceExecution(): Boolean {
        draftSequenceExecutionSession?.complete()
        draftSequenceExecutionSession = null

        val draftSequenceDurationMs = if (draftSequenceStartTimeMs > 0L) {
            (SystemClock.uptimeMillis() - draftSequenceStartTimeMs).coerceAtLeast(0L)
        } else {
            0L
        }
        modelUpdate.drainOnce()?.let { (workloadDurations, admissionDecisions) ->
            predictor.learnFromCapture(workloadDurations, admissionDecisions, draftSequenceDurationMs)
        }
        // Feed the observed duration into the context used by subsequent two-Draft pacing decisions.
        captureAvailablePacer.endDraftSequence(sizeBucket, draftSequenceDurationMs)

        val isTimeout = captureMetrics.timeoutTimestampMsOrDefault < SystemClock.uptimeMillis()
        metricsRecorder.onCaptureEnd(isTimeout)
        return isTimeout
    }

    /** Cancels the pending RESERVED workload without discarding collected samples. */
    fun cancelDraftSequenceExecution() {
        draftSequenceExecutionSession?.cancel()
        draftSequenceExecutionSession = null
        captureAvailablePacer.cancelDraftSequence(sizeBucket)
    }

    private fun resolveWorkloadSequenceKey(node: Node, workloadKey: WorkloadKey): List<WorkloadKey> {
        val index = draftSequenceNodeList.indexOfFirst { it === node }
        return if (index >= 0) {
            draftSequenceNodeList.drop(index).mapNotNull { resolveWorkloadKey(it, requireReadyToRun = false) }
        } else {
            listOf(workloadKey)
        }
    }

    private fun resolveWorkloadKey(node: Node, requireReadyToRun: Boolean): WorkloadKey? {
        return when (node) {
            is SecDualBokehNodeBase -> WorkloadKey.Bokeh(sizeBucket)
                .takeIf { !requireReadyToRun || node.isMaxInputCount() }
            is SecFilterNode -> WorkloadKey.Filter(sizeBucket)
            is DynamicFunctionNode -> WorkloadKey.DynamicFunction(sizeBucket)
            is WatermarkNode -> WorkloadKey.Watermark(sizeBucket, node.watermarkType)
            is SecImageCodecNodeBase -> {
                when (node.codecUsage) {
                    CodecConfiguration.DECODE -> WorkloadKey.Decoding(sizeBucket)
                    CodecConfiguration.ENCODE -> WorkloadKey.Encoding(
                        sizeBucket,
                        captureMetrics.resultImageFormat,
                        isPendingRequest,
                    )
                    else -> error("not supported codecUsage(${node.codecUsage})")
                }
            }
            else -> null
        }
    }

    fun deinitialize() {
        draftNodeChainLifecycle.deinitializeOnce()
    }
}

/**
 * What one capture teaches the Predictor: actual workload durations plus the decisions that produced them, buffered
 * during node execution and drained exactly once at capture end. Cancelling does not clear it - a later complete still
 * drains the samples collected so far.
 */
private class ModelUpdateBuffer {
    private val lock = Any()
    private val workloadDurations = mutableMapOf<WorkloadKey, Long>()
    private val decisions = mutableMapOf<WorkloadSequenceKey, AdmissionDecision>()
    private var drained = false

    fun recordWorkloadDuration(workloadKey: WorkloadKey, durationMs: Long) {
        synchronized(lock) {
            workloadDurations[workloadKey] = durationMs.coerceAtLeast(0L)
        }
    }

    fun remember(decision: AdmissionDecision) {
        synchronized(lock) {
            decisions[decision.workloadSequenceKey] = decision
        }
    }

    /** Returns the buffered durations and decisions on the first call, null afterwards. */
    fun drainOnce(): Pair<Map<WorkloadKey, Long>, List<AdmissionDecision>>? {
        synchronized(lock) {
            if (drained) {
                return null
            }
            drained = true
            return Pair(workloadDurations.toMap(), decisions.values.toList())
        }
    }
}

/**
 * Sole writer of the [CaptureMetrics]/[DraftSequenceMetrics] observability store, which nothing model-facing reads -
 * kept in one place so retiring it in favour of logs is a single-class change.
 *
 * Writers arrive from three threads (node execution, workload completion, watchdog), so every mutation takes the
 * [draftSequenceMetrics] monitor to give the export reader one happens-before edge over the lists and the flags alike.
 */
private class MetricsRecorder(
    captureMetrics: CaptureMetrics,
    private val draftSequenceMetrics: DraftSequenceMetrics,
    isPendingRequest: Boolean,
) {

    init {
        draftSequenceMetrics.isPendingRequest = isPendingRequest
        captureMetrics.draftSequenceMetrics = draftSequenceMetrics
    }

    fun onDraftStart(gatingPacingDecision: CaptureAvailablePacingDecision?, pacerSessionId: Long?) {
        synchronized(draftSequenceMetrics) {
            draftSequenceMetrics.draftStartUptimeMs = SystemClock.uptimeMillis()
            draftSequenceMetrics.pacerSessionId = pacerSessionId
            if (gatingPacingDecision != null) {
                draftSequenceMetrics.captureAvailablePacing = gatingPacingDecision.toCaptureAvailablePacingMetrics()
            }
        }
    }

    fun onNodeExecutionStart(
        nodeName: String,
        workloadKey: WorkloadKey,
        preExecutionMetrics: PreExecutionMetrics,
    ): NodeExecutionMetrics {
        val nodeExecutionMetrics = NodeExecutionMetrics(
            nodeName = nodeName,
            preExecutionMetrics = preExecutionMetrics,
            workloadKey = workloadKey.toReplayString(),
            startUptimeMs = SystemClock.uptimeMillis(),
        )
        synchronized(draftSequenceMetrics) {
            draftSequenceMetrics.nodeExecutionMetricsList += nodeExecutionMetrics
        }
        return nodeExecutionMetrics
    }

    fun onPrediction(prediction: ExecutionPrediction) {
        synchronized(draftSequenceMetrics) {
            draftSequenceMetrics.nodeExecutionPredictionList += prediction
        }
    }

    fun onWatchdogArmed(nodeExecutionMetrics: NodeExecutionMetrics, watchdogTimeoutMs: Long) {
        synchronized(draftSequenceMetrics) {
            nodeExecutionMetrics.watchdogTimeoutMs = watchdogTimeoutMs
            nodeExecutionMetrics.watchdogTimedOut = false
        }
    }

    fun onWatchdogTimedOut(nodeExecutionMetrics: NodeExecutionMetrics) {
        synchronized(draftSequenceMetrics) {
            nodeExecutionMetrics.watchdogTimedOut = true
            draftSequenceMetrics.hasWatchdogTimeout = true
        }
    }

    fun onWorkloadCompleted(nodeExecutionMetrics: NodeExecutionMetrics, postExecutionMetrics: PostExecutionMetrics) {
        synchronized(draftSequenceMetrics) {
            nodeExecutionMetrics.postExecutionMetrics = postExecutionMetrics
        }
    }

    fun onCaptureEnd(isTimeout: Boolean) {
        synchronized(draftSequenceMetrics) {
            draftSequenceMetrics.isTimeout = isTimeout
            draftSequenceMetrics.draftEndUptimeMs = SystemClock.uptimeMillis()
        }
    }
}

/**
 * Owns the draft node chain's deinit timing, exactly once per draft sequence. [deinitializeOnce] normally deinitializes
 * straight away, but a timed-out workload leaves its worker running on the chain, so [deferUntil] records that worker
 * and deinit waits for it. Both run on the process thread, [deferUntil] always first, so there is no ordering to
 * reconcile beyond recording the worker.
 */
private class DraftNodeChainLifecycle {
    private val lock = Any()
    private var accessor: DraftNodeChainAccessor? = null
    private var pendingWorker: CompletableFuture<*>? = null
    private var deinitialized = false

    fun attach(accessor: DraftNodeChainAccessor) {
        synchronized(lock) {
            this.accessor = accessor
        }
    }

    /** A timed-out workload's worker is still running on the chain; defer deinit until it finishes. */
    fun deferUntil(worker: CompletableFuture<*>) {
        synchronized(lock) {
            pendingWorker = worker
        }
    }

    /** Deinitializes the chain exactly once, after the pending timed-out worker (if any) finishes. */
    fun deinitializeOnce() {
        val (accessor, worker) = synchronized(lock) {
            if (deinitialized) {
                return
            }
            deinitialized = true
            Pair(accessor, pendingWorker)
        }
        if (accessor == null) {
            return
        }

        val deinit = {
            try {
                accessor.deinitializeNodeChain()
            } catch (t: Throwable) {
                CLog.e(TAG, "deinitialize error", t)
            }
        }
        if (worker == null || worker.isDone) {
            deinit()
        } else {
            worker.whenComplete { _, _ -> deinit() }
        }
    }
}
